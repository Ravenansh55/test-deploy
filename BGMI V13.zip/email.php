<?php
$emailku = 'igodxabbuop@gmail.com'; // GANTI EMAIL KAMU DISINI
?>